package cn.test.bookms.entity;

import java.io.Serializable;

public class BookType implements Serializable {
    private Integer id;

    private String tname;

    private static final long serialVersionUID = 1L;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getTname() {
        return tname;
    }

    public void setTname(String tname) {
        this.tname = tname == null ? null : tname.trim();
    }
}